#ifndef FCS_SDK_FCS_CONFIG_H
#define FCS_SDK_FCS_CONFIG_H

// Базовые настройки SDK (при необходимости могут расширяться)

// Версия SDK
#define FCS_SDK_VERSION_MAJOR 1
#define FCS_SDK_VERSION_MINOR 0
#define FCS_SDK_VERSION_PATCH 0

#endif // FCS_SDK_FCS_CONFIG_H
