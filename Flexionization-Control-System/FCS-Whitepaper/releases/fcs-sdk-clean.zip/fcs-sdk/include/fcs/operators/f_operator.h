#ifndef FCS_SDK_F_OPERATOR_H
#define FCS_SDK_F_OPERATOR_H

namespace fcs {

    // Линейный оператор F: X = kF * Δ
    double default_F(double delta);

}

#endif

