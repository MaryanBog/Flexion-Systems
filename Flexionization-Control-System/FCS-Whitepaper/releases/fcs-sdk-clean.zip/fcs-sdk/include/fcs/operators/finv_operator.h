#ifndef FCS_SDK_FINV_OPERATOR_H
#define FCS_SDK_FINV_OPERATOR_H

namespace fcs {

    // Инверсия к линейному F
    double default_FInv(double x);

}

#endif
