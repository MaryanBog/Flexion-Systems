#ifndef FCS_SDK_G_OPERATOR_H
#define FCS_SDK_G_OPERATOR_H

namespace fcs {

    // Линейная форма управляющего сигнала
    double default_G(double delta);

}

#endif

