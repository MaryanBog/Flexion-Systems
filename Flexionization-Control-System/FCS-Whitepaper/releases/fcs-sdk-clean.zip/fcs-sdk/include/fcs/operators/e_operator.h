#ifndef FCS_SDK_E_OPERATOR_H
#define FCS_SDK_E_OPERATOR_H

namespace fcs {

    // Линейный оператор E: сглаживание или корректировка
    double default_E(double x);

}

#endif
